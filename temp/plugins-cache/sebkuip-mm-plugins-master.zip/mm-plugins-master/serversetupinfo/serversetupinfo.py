import discord
from discord.ext import commands
import datetime

from core import checks
from core.models import PermissionLevel

class ServerSetupInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def get_permissions(self, user: discord.Member):
        if await self.bot.is_owner(user) or user == self.bot.user.id:
            return PermissionLevel.OWNER
        permissions = PermissionLevel.ADMINISTRATOR if user.guild_permissions.administrator else PermissionLevel.REGULAR
        checkables = user.roles.extend([user])

        for level in PermissionLevel:
            for value in checkables:
                if level > permissions and value in self.bot.config["command_permissions"][level]:
                    permissions = level
        return permissions

    @checks.has_permissions(PermissionLevel.MODERATOR)
    @commands.command(name="ssu", help="Displays the server startup information")
    @commands.cooldown(1, 3600, type=commands.BucketType.guild)
    async def ssu(self, ctx: commands.Context):
        info_embed=discord.Embed(title="London Server Startup", description=f"  Come and visit the City of London! There is a server startup ongoing!\n\n  https://www.roblox.com/games/17428786424/City-of-London\n\n  **SSU hosted by {ctx.author.mention}**", color=0x013a93, url="https://www.roblox.com/games/17428786424/City-of-London")
        info_embed.set_author(name="United Kingdom")
        info_embed.set_footer(text="Updated at")
        info_embed.timestamp = ctx.message.created_at
        info_embed.set_image(url="https://images-ext-1.discordapp.net/external/8eftouOgKVHU3gYu0C7hH1v65Vm7mXy6dRMhwcv5Zfc/https/i.ibb.co/wdcTLdc/Webp-34.png")

        log_embed=discord.Embed(title="ssu command ran", description=f"  **{ctx.author.mention}** ran the ssu command", color=0x013a93)
        permissionlevel = await self.get_permissions(ctx.author)
        log_embed.add_field(name="Permissions", value=permissionlevel.name, inline=False)
        log_embed.set_footer(text="Ran at")
        log_embed.timestamp = ctx.message.created_at

        info_channel = self.bot.get_channel(1242946917667962992)
        log_channel = self.bot.get_channel(1283086005280440360)

        await info_channel.send("||@here <@&1266541268100448266>||", embed=info_embed)
        await log_channel.send(embed=log_embed)

    @ssu.error
    async def ssu_error(self, ctx: commands.Context, error: commands.CommandError):
        if isinstance(error, commands.CheckFailure):
            await ctx.send(embed=discord.Embed(title="Error", description="You do not have the required permissions to run this command.", color=0xff0000))
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(embed=discord.Embed(title="Error", description=f"This command is on cooldown. Please try again <t:{round((discord.utils.utcnow() + datetime.timedelta(seconds=error.retry_after)).timestamp())}:R>.", color=0xff0000))
        else:
            await ctx.command.reset_cooldown(ctx)
            raise error

async def setup(bot):
    await bot.add_cog(ServerSetupInfo(bot))