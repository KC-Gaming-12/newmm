---
name: Bug Report
about: If any plugin is not working the way it should work
labels: bug
---

Please provide details about:

* What command you're trying to run
* What happened
* What you expected to happen
