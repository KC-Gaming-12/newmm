---
name: Feature Request
about: Suggestions for new plugins or existing plugins
labels: Suggestion
---

Please provide us with:

*  Details about your feature request
