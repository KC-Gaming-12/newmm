# Security Notice

The Security Notice for Python Discord projects can be found [on our website](https://pydis.com/security.md).
