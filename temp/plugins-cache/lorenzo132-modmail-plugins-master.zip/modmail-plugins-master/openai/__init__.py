"""
Plugin for integrating OpenAI API to respond in modmail tickets.
"""

__version__ = '1.0.0'
__author__ = 'Your Name'