Free to use modmail-plugins for [Kyber's Discord modmail](https://github.com/kyb3r/modmail)
(^>^)
