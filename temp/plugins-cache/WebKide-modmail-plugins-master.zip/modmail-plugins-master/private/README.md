<div align="center">
<h1>「modmail-plugins」</h1>
<p><b><i>plugins to expand Modmail2020's functionality 🍆💦🍑</i></b></p>
</div>


<div align="center">
<img src="http://forthebadge.com/images/badges/made-with-crayons.svg?style=for-the-badge" alt="made with crayons"><br>
<img src="https://img.shields.io/badge/python-v3.7-12a4ff?style=for-the-badge&logo=python&logoColor=12a4ff">
<img src="https://img.shields.io/badge/library-discord%2Epy-ffbb10?style=for-the-badge">

<p>🛠️ This plugin is meant for my private-personal guild, it will not work on yours because it relies on personalised elements updated by hand on my guild.</p>
<br><br>
</div>

# Private

you shouldn't be using this plugin, why are you still reading this?

# Installation

🔸 <b>Installation</b>: `{p}plugin add WebKide/modmail-plugins/private@master`

> `{p}` will be your guild's prefix, by default it is **`?`** unless you changed it

- - - -
Commands...
#### Usage and examples ####
|    **operation**  	 	|    **usage example**  	 	|    **day support**    |
|:-----------------------:	|:-----------------------:	|:----------------------:	|
|  nudge  |  `{p}nudge`  |    {p}nudge [birthday]    |



> please do not ask for support for this plugin, thanks.
