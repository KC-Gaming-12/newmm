<div align="center">
  <img src="https://i.imgur.com/XyGXFPk.png">
  <p><strong><i>Plugins that extend the functionality of discord Modmail</i></strong></p>
</div>
